play-ldap
=========

Play Module for accessing a LDAP Directory in an easy way