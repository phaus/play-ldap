play-ldap
=========

Play Module for accessing a LDAP Direcotry in an easy way